# Deploy VESTCASA on Netlify

This app uses TanStack Start server routes for Firebot Pix creation, status checks, and webhooks. It must run with the Nitro Netlify preset; do not publish `dist/client` as this project does not configure that directory.

## Netlify settings

The included `netlify.toml` sets:
- Build command: `bun run build`
- Publish directory: `.netlify/public`
- `NITRO_PRESET=netlify`

If Netlify has UI overrides, remove the old `dist/client` publish directory and let the repository's `netlify.toml` control the build settings.

## Required environment variable

In Netlify: Site configuration → Environment variables, set `FIREBOT_API_KEY` to the private API key from Firebot. Never use a `VITE_` prefix and never commit the real key.

## Deploy and verify

1. Commit/push the project including `netlify.toml`.
2. Trigger a fresh deploy with cache cleared if the old configuration persists.
3. Confirm the build log reports the Netlify Nitro output and that the deployed site loads.
4. Test checkout with a small legitimate transaction and verify status from Firebot.

A successful static build alone does not prove payment routes or provider credentials work. The real Firebot API key and a live deployment are required to test payments end-to-end.
