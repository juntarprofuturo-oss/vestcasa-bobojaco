import { createFileRoute } from "@tanstack/react-router";

// The checkout independently checks the transaction status against Firebot.
// Keep this endpoint lightweight; never trust a webhook alone to mark an order paid.
export const Route = createFileRoute("/api/public/firebot-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body: any = await request.json().catch(() => null);
        console.log("firebot webhook received", body?.event ?? body?.status ?? "unknown");
        return Response.json({ ok: true });
      },
    },
  },
});
