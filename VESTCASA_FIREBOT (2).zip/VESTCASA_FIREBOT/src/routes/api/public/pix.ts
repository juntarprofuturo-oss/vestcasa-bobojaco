import { createFileRoute } from "@tanstack/react-router";

const PRICE_CENTS = 3990;
const API = "https://firebotbr.com/api";

type FirebotTransaction = {
  success?: boolean;
  transactionId?: string;
  saleId?: string;
  amount?: number | string;
  pixCopiaECola?: string;
  qrCodeUrl?: string;
  status?: string;
  data?: {
    transactionId?: string;
    amount?: number | string;
    pixCopiaECola?: string;
    qrCodeUrl?: string;
    status?: string;
  };
  error?: string;
  message?: string;
};

const jsonHeaders = { "Content-Type": "application/json", Accept: "application/json" };

function normalizedStatus(value: unknown): string {
  const status = String(value ?? "PENDING").toUpperCase();
  if (["PAID", "APPROVED", "CONFIRMED", "COMPLETED", "SUCCESS"].includes(status)) return "paid";
  if (["EXPIRED", "CANCELED", "CANCELLED", "FAILED", "REFUSED"].includes(status)) return status === "EXPIRED" ? "expired" : "failed";
  return "pending";
}

export const Route = createFileRoute("/api/public/pix")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["FIREBOT_API_KEY"];
        if (!key) return Response.json({ error: "Pagamento indisponível: configure FIREBOT_API_KEY no ambiente do servidor." }, { status: 503 });

        let body: any;
        try {
          body = await request.json();
        } catch {
          return Response.json({ error: "JSON inválido" }, { status: 400 });
        }

        const items = Array.isArray(body?.items) ? body.items.slice(0, 30) : [];
        const qty = items.reduce((a: number, i: any) => a + Math.max(1, Math.min(20, Math.floor(Number(i?.q) || 0))), 0);
        const c = body?.c ?? {};
        if (!qty || !c.nome || !c.email || !c.cpf) {
          return Response.json({ error: "Dados incompletos" }, { status: 422 });
        }

        const origin = new URL(request.url).origin;
        const amountCents = PRICE_CENTS * qty;
        try {
          const res = await fetch(`${API}/v1/pix/create`, {
            method: "POST",
            headers: { ...jsonHeaders, "x-api-key": key },
            body: JSON.stringify({
              amount: amountCents / 100,
              description: `Pedido ${String(body?.id ?? "").slice(0, 40)}`,
              customer: {
                name: String(c.nome).slice(0, 120),
                email: String(c.email).slice(0, 120),
                cpf: String(c.cpf).replace(/\D/g, "").slice(0, 14),
                phone: c.tel ? String(c.tel).replace(/\D/g, "").slice(0, 20) : undefined,
              },
              webhook_url: `${origin}/api/public/firebot-webhook`,
              metadata: { pedido_id: String(body?.id ?? "").slice(0, 40) },
            }),
          });

          const data = (await res.json().catch(() => ({}))) as FirebotTransaction;
          const tx = data.data ?? data;
          const id = tx.transactionId;
          const brCode = tx.pixCopiaECola;
          const qrCodeUrl = tx.qrCodeUrl;
          if (!res.ok || !id || !brCode) {
            const message = data.message ?? data.error ?? "A Firebot não conseguiu gerar o Pix.";
            return Response.json({ error: message }, { status: res.status >= 400 ? res.status : 502 });
          }

          const parsedAmount = Number(tx.amount);
          return Response.json({
            id,
            br_code: brCode,
            qrCodeUrl,
            amount: Number.isFinite(parsedAmount) && parsedAmount > 0 ? Math.round(parsedAmount * 100) : amountCents,
          });
        } catch (error) {
          console.error("Firebot PIX create failed", error);
          return Response.json({ error: "Não foi possível conectar à API de pagamentos. Tente novamente." }, { status: 502 });
        }
      },
      GET: async ({ request }) => {
        const key = process.env["FIREBOT_API_KEY"];
        const id = new URL(request.url).searchParams.get("id") ?? "";
        if (!key) return Response.json({ error: "Pagamento indisponível" }, { status: 503 });
        if (!/^[A-Za-z0-9_#-]{1,100}$/.test(id)) return Response.json({ error: "ID de transação inválido" }, { status: 400 });

        try {
          const res = await fetch(`${API}/v1/pix/${encodeURIComponent(id)}`, {
            headers: { "x-api-key": key, Accept: "application/json" },
          });
          const data = (await res.json().catch(() => ({}))) as FirebotTransaction;
          if (!res.ok) return Response.json({ error: data.message ?? data.error ?? "Não foi possível consultar o pagamento" }, { status: res.status });
          return Response.json({ status: normalizedStatus(data.data?.status ?? data.status) });
        } catch (error) {
          console.error("Firebot PIX status check failed", error);
          return Response.json({ error: "Não foi possível consultar o pagamento" }, { status: 502 });
        }
      },
    },
  },
});
