import { createFileRoute } from "@tanstack/react-router";
import ogImage from "@/assets/bobojaco-og.png.asset.json";

const OG_IMAGE_URL = `https://id-preview--ed2fcc9b-eb49-4eab-ac43-94c0360083c7.lovable.app${ogImage.url}`;

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Bobojaco · Vestcasa" },
      { name: "description", content: "Bobojaco · jaqueta acolchoada com capuz da Vestcasa." },
      { property: "og:title", content: "Bobojaco · Vestcasa" },
      { property: "og:description", content: "Bobojaco · jaqueta acolchoada com capuz da Vestcasa." },
      { property: "og:type", content: "website" },
      { property: "og:image", content: OG_IMAGE_URL },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:image", content: OG_IMAGE_URL },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/bobojaco.html"
      title="Bobojaco · loja e checkout Vestcasa"
      className="block h-dvh w-full border-0 bg-background"
    />
  );
}
